<section class="project-brand-landing-section">
    <div class="project-brand-landing-container container">
        <aside class="project-text-wrapper">
            <div class="top-text">
                <div class="number">
                    <p>+4200</p>
                </div>
                <div class="text">
                    <p>پـروژه موفق</p>
                </div>
            </div>
            <div class="bott-text">
                <p>جـای شـــــــــــما خالیسـت...</p>
            </div>
        </aside>
        <aside class="brand-wrapper">
            <div class="slider-swiper">
                <div class="swiper mySwiper">
                    <div class="swiper-wrapper">
                        <?php
                        $theme_options = get_option('cyberisho_main_option', []);
                        $site_info_options = $theme_options['site-info'];
                        ?>
                        <?php
                        $brand_images = $site_info_options['brand_images'];
                        if (!empty($brand_images) && is_array($brand_images)) {
                            foreach ($brand_images as $brand) {
                                if (!empty($brand['image'])) {
                                    ?>
                                    <div class="swiper-slide">
                                        <img src="<?php echo esc_url($brand['image']); ?>" alt="Image 1" />
                                    </div>
                                    <?php
                                }
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </aside>
    </div>
</section>