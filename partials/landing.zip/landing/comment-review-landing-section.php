<section class="comment-review-landing-section landing-item-section">
        <div class="comment-review-landing-container">
          <div class="purple-ball-icon item-one ease-icon-animation-low">
            <div class="inside">
              <img src="./assets/img/ball.png" alt="" />
            </div>
          </div>
          <div class="purple-ball-icon item-two ease-icon-animation-low">
            <div class="inside">
              <img src="./assets/img/ball.png" alt="" />
            </div>
          </div>
          <div class="purple-ball-icon item-three ease-icon-animation-low">
            <div class="inside">
              <img src="./assets/img/ball.png" alt="" />
            </div>
          </div>
          <div class="right-text-side">
            <div class="title">
              <p>نظرات مشتریان</p>
            </div>
            <div class="text">
              <p>بازخوردهای برخی از کارفرمایان و مشتریان محترم ما</p>
            </div>
          </div>
          <div class="comment-review-swiper">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <div class="text-content">
                  <p>
                    در طراحی سایت یکمی ما وسواس داشتیم و به ویرایش کردن و
                    تغییرات چند مرحله ای رسید کارمون اما با احترام تمام پذیرای
                    خواسته های ما بودین و این خیلی ارزشمند بود برامون...
                  </p>
                </div>
                <div class="name-text">
                  <p>محمدرضا فاطمی - سایت فولادگسترش</p>
                </div>

                <div class="audio-player">
                  <audio
                    id="audio"
                    src="./central.mp3"
                    type="audio/mpeg"
                    preload="auto"
                    oncontextmenu="return false;"
                  ></audio>
                  <div id="progress-bar">
                    <div id="progress"></div>
                  </div>
                  <svg id="play-icon" viewBox="0 0 330 330">
                    <path
                      d="M37.728,328.12c2.266,1.256,4.77,1.88,7.272,1.88c2.763,0,5.522-0.763,7.95-2.28l240-149.999
                          c4.386-2.741,7.05-7.548,7.05-12.72c0-5.172-2.664-9.979-7.05-12.72L52.95,2.28c-4.625-2.891-10.453-3.043-15.222-0.4
                          C32.959,4.524,30,9.547,30,15v300C30,320.453,32.959,325.476,37.728,328.12z"
                      fill="black"
                    ></path>
                  </svg>
                  <svg
                    class="pause-svg"
                    viewBox="0 0 48 48"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect width="48" height="48" fill="none"></rect>
                    <path
                      d="M16 12V36"
                      stroke="black"
                      stroke-width="4"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    ></path>
                    <path
                      d="M32 12V36"
                      stroke="black"
                      stroke-width="4"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    ></path>
                  </svg>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="text-content">
                  <p>
                    در طراحی سایت یکمی ما وسواس داشتیم و به ویرایش کردن و
                    تغییرات چند مرحله ای رسید کارمون اما با احترام تمام پذیرای
                    خواسته های ما بودین و این خیلی ارزشمند بود برامون...
                  </p>
                </div>
                <div class="name-text">
                  <p>محمدرضا فاطمی - سایت فولادگسترش</p>
                </div>

                <div class="audio-player">
                  <audio
                    id="audio"
                    src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
                  ></audio>
                  <div id="progress-bar">
                    <div id="progress"></div>
                  </div>
                  <svg id="play-icon" viewBox="0 0 330 330">
                    <path
                      d="M37.728,328.12c2.266,1.256,4.77,1.88,7.272,1.88c2.763,0,5.522-0.763,7.95-2.28l240-149.999
                          c4.386-2.741,7.05-7.548,7.05-12.72c0-5.172-2.664-9.979-7.05-12.72L52.95,2.28c-4.625-2.891-10.453-3.043-15.222-0.4
                          C32.959,4.524,30,9.547,30,15v300C30,320.453,32.959,325.476,37.728,328.12z"
                      fill="black"
                    ></path>
                  </svg>
                  <svg
                    class="pause-svg"
                    viewBox="0 0 48 48"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect width="48" height="48" fill="none"></rect>
                    <path
                      d="M16 12V36"
                      stroke="black"
                      stroke-width="4"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    ></path>
                    <path
                      d="M32 12V36"
                      stroke="black"
                      stroke-width="4"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    ></path>
                  </svg>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="text-content">
                  <p>
                    در طراحی سایت یکمی ما وسواس داشتیم و به ویرایش کردن و
                    تغییرات چند مرحله ای رسید کارمون اما با احترام تمام پذیرای
                    خواسته های ما بودین و این خیلی ارزشمند بود برامون...
                  </p>
                </div>
                <div class="name-text">
                  <p>محمدرضا فاطمی - سایت فولادگسترش</p>
                </div>

                <div class="audio-player">
                  <audio
                    id="audio"
                    src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
                  ></audio>
                  <div id="progress-bar">
                    <div id="progress"></div>
                  </div>
                  <svg id="play-icon" viewBox="0 0 330 330">
                    <path
                      d="M37.728,328.12c2.266,1.256,4.77,1.88,7.272,1.88c2.763,0,5.522-0.763,7.95-2.28l240-149.999
                          c4.386-2.741,7.05-7.548,7.05-12.72c0-5.172-2.664-9.979-7.05-12.72L52.95,2.28c-4.625-2.891-10.453-3.043-15.222-0.4
                          C32.959,4.524,30,9.547,30,15v300C30,320.453,32.959,325.476,37.728,328.12z"
                      fill="black"
                    ></path>
                  </svg>
                  <svg
                    class="pause-svg"
                    viewBox="0 0 48 48"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect width="48" height="48" fill="none"></rect>
                    <path
                      d="M16 12V36"
                      stroke="black"
                      stroke-width="4"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    ></path>
                    <path
                      d="M32 12V36"
                      stroke="black"
                      stroke-width="4"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    ></path>
                  </svg>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="text-content">
                  <p>
                    در طراحی سایت یکمی ما وسواس داشتیم و به ویرایش کردن و
                    تغییرات چند مرحله ای رسید کارمون اما با احترام تمام پذیرای
                    خواسته های ما بودین و این خیلی ارزشمند بود برامون...
                  </p>
                </div>
                <div class="name-text">
                  <p>محمدرضا فاطمی - سایت فولادگسترش</p>
                </div>

                <div class="audio-player">
                  <audio
                    id="audio"
                    src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
                  ></audio>
                  <div id="progress-bar">
                    <div id="progress"></div>
                  </div>
                  <svg id="play-icon" viewBox="0 0 330 330">
                    <path
                      d="M37.728,328.12c2.266,1.256,4.77,1.88,7.272,1.88c2.763,0,5.522-0.763,7.95-2.28l240-149.999
                          c4.386-2.741,7.05-7.548,7.05-12.72c0-5.172-2.664-9.979-7.05-12.72L52.95,2.28c-4.625-2.891-10.453-3.043-15.222-0.4
                          C32.959,4.524,30,9.547,30,15v300C30,320.453,32.959,325.476,37.728,328.12z"
                      fill="black"
                    ></path>
                  </svg>
                  <svg
                    class="pause-svg"
                    viewBox="0 0 48 48"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect width="48" height="48" fill="none"></rect>
                    <path
                      d="M16 12V36"
                      stroke="black"
                      stroke-width="4"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    ></path>
                    <path
                      d="M32 12V36"
                      stroke="black"
                      stroke-width="4"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    ></path>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>