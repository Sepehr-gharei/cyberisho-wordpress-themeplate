<section class="portfolio-landing-item-section landing-item-section">
        <div class="portfolio-landing-item-container">
          <div class="title-wrapper">
            <h3>نمونه کار های ما</h3>
            <div class="audio-wrapper">
              <div class="voice-field">
                <div class="player">
                  <div class="border-frame"></div>
                  <div class="progress-border"></div>

                  <button>
                    <p>توضیحات بیشتر</p>
                    <!-- آیکون قبل از پخش -->
                    <svg id="play-icon" viewBox="0 0 330 330">
                      <path
                        d="M37.728,328.12c2.266,1.256,4.77,1.88,7.272,1.88c2.763,0,5.522-0.763,7.95-2.28l240-149.999
                        c4.386-2.741,7.05-7.548,7.05-12.72c0-5.172-2.664-9.979-7.05-12.72L52.95,2.28c-4.625-2.891-10.453-3.043-15.222-0.4
                        C32.959,4.524,30,9.547,30,15v300C30,320.453,32.959,325.476,37.728,328.12z"
                        fill="black"
                      ></path>
                    </svg>
                  </button>

                  <audio src="./central.mp3" preload="none"></audio>
                </div>
              </div>
            </div>
          </div>

          <div class="swiper portfolioSwiper">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <img
                  src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=400"
                  alt="Landscape 1"
                />
                <div class="slide-content">
                  <p>منظره‌ای از کوهستان و دریاچه</p>
                </div>
              </div>
              <div class="swiper-slide">
                <img
                  src="https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=400"
                  alt="Landscape 2"
                />
                <div class="slide-content">
                  <p>منظره‌ای زمستانی از قله‌های برفی</p>
                </div>
              </div>
              <div class="swiper-slide">
                <img
                  src="https://images.unsplash.com/photo-1446329813274-7c9036bd9a1f?auto=format&fit=crop&w=400"
                  alt="Landscape 3"
                />
                <div class="slide-content">
                  <p>منظره‌ای از جنگل و رودخانه</p>
                </div>
              </div>
              <div class="swiper-slide">
                <img
                  src="https://images.unsplash.com/photo-1509233725247-49e657c61113?auto=format&fit=crop&w=400"
                  alt="Landscape 4"
                />
                <div class="slide-content">
                  <p>منظره‌ای از امواج دریا و صخره‌ها</p>
                </div>
              </div>
              <div class="swiper-slide">
                <img
                  src="https://images.unsplash.com/photo-1519046904884-53103b34b206?auto=format&fit=crop&w=400"
                  alt="Landscape 5"
                />
                <div class="slide-content">
                  <p>منظره‌ای از امواج دریا بر روی سنگ‌ها</p>
                </div>
              </div>
              <div class="swiper-slide">
                <img
                  src="https://images.unsplash.com/photo-1470770841072-f978cf13d08c?auto=format&fit=crop&w=400"
                  alt="Landscape 6"
                />
                <div class="slide-content">
                  <p>منظره‌ای از آبشار در جنگل</p>
                </div>
              </div>
              <div class="swiper-slide">
                <img
                  src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=400"
                  alt="Landscape 7"
                />
                <div class="slide-content">
                  <p>منظره‌ای از غروب خورشید</p>
                </div>
              </div>
              <div class="swiper-slide">
                <img
                  src="https://images.unsplash.com/photo-1505852679233-d9fd70aff56d?auto=format&fit=crop&w=400"
                  alt="Landscape 8"
                />
                <div class="slide-content">
                  <p>منظره‌ای از یک دره سرسبز</p>
                </div>
              </div>
            </div>
          </div>
          <div class="button-wrapper">
            <a href="">مشاهده همه نمونه کار ها</a>
          </div>
        </div>
      </section>